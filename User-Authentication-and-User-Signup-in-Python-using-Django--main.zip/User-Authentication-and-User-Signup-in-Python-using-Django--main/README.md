Complete Auth flow explanation for django project.

Star it for future.


Youtube Video 
https://www.youtube.com/watch?v=OojA7SPViEs
